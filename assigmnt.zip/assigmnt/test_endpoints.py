import pytest
from app import app, db

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client
        with app.app_context():
            db.drop_all()

def test_create_furniture(client):
    # Test creating a new furniture item
    response = client.post('/furniture', data={
        'name': 'Chair',
        'description': 'Comfortable chair',
        'quantity': 10,
        'location': 'Living room'
    })
    assert response.status_code == 201

    # Test retrieving the created furniture item
    response = client.get('/furniture')
    data = response.json
    assert len(data['furniture']) == 1
    assert data['furniture'][0]['name'] == 'Chair'

def test_update_furniture(client):
    # Create a furniture item
    client.post('/furniture', data={
        'name': 'Table',
        'description': 'Wooden table',
        'quantity': 5,
        'location': 'Dining room'
    })

    # Retrieve the ID of the created furniture item
    response = client.get('/furniture')
    furniture_id = response.json['furniture'][0]['id']

    # Update the furniture item
    updated_data = {
        'name': 'Table',
        'description': 'Sturdy wooden table',
        'quantity': 3,
        'location': 'Living room'
    }
    response = client.put(f'/furniture/{furniture_id}', data=updated_data)
    assert response.status_code == 200

    # Test retrieving the updated furniture item
    response = client.get('/furniture')
    data = response.json
    assert len(data['furniture']) == 1
    assert data['furniture'][0]['description'] == 'Sturdy wooden table'
    assert data['furniture'][0]['quantity'] == 3
    assert data['furniture'][0]['location'] == 'Living room'

def test_delete_furniture(client):
    # Create a furniture item
    client.post('/furniture', data={
        'name': 'Desk',
        'description': 'Wooden desk',
        'quantity': 1,
        'location': 'Office'
    })

    # Retrieve the ID of the created furniture item
    response = client.get('/furniture')
    furniture_id = response.json['furniture'][0]['id']

    # Delete the furniture item
    response = client.delete(f'/furniture/{furniture_id}')
    assert response.status_code == 200

    # Test retrieving the deleted furniture item
    response = client.get('/furniture')
    data = response.json
    assert len(data['furniture']) == 0
