import unittest
from app import app, db
from app import Furniture


class TestCRUDOperations(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        with app.app_context():
            db.create_all()

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def test_create_furniture(self):
        # Create a new furniture item
        new_furniture = Furniture(name='Chair', description='Comfortable chair', quantity=10, location='Office')
        db.session.add(new_furniture)
        db.session.commit()

        # Retrieve the newly created furniture item from the database
        saved_furniture = Furniture.query.filter_by(name='Chair').first()

        # Assert that the retrieved furniture item is not None
        self.assertIsNotNone(saved_furniture)

    def test_read_furniture(self):
        # Create a new furniture item
        new_furniture = Furniture(name='Table', description='Wooden table', quantity=5, location='Living Room')
        db.session.add(new_furniture)
        db.session.commit()

        # Retrieve the newly created furniture item from the database
        saved_furniture = Furniture.query.filter_by(name='Table').first()

        # Assert that the retrieved furniture item matches the expected values
        self.assertEqual(saved_furniture.name, 'Table')
        self.assertEqual(saved_furniture.description, 'Wooden table')
        self.assertEqual(saved_furniture.quantity, 5)
        self.assertEqual(saved_furniture.location, 'Living Room')

    def test_update_furniture(self):
        # Create a new furniture item
        new_furniture = Furniture(name='Sofa', description='Comfortable sofa', quantity=3, location='Living Room')
        db.session.add(new_furniture)
        db.session.commit()

        # Retrieve the newly created furniture item from the database
        saved_furniture = Furniture.query.filter_by(name='Sofa').first()

        # Update the furniture item
        saved_furniture.name = 'New Sofa'
        saved_furniture.description = 'Luxurious sofa'
        saved_furniture.quantity = 2
        saved_furniture.location = 'Bedroom'
        db.session.commit()

        # Retrieve the updated furniture item from the database
        updated_furniture = Furniture.query.filter_by(name='New Sofa').first()

        # Assert that the retrieved updated furniture item matches the expected values
        self.assertEqual(updated_furniture.name, 'New Sofa')
        self.assertEqual(updated_furniture.description, 'Luxurious sofa')
        self.assertEqual(updated_furniture.quantity, 2)
        self.assertEqual(updated_furniture.location, 'Bedroom')

    def test_delete_furniture(self):
        # Create a new furniture item
        new_furniture = Furniture(name='Desk', description='Wooden desk', quantity=1, location='Office')
        db.session.add(new_furniture)
        db.session.commit()

        # Retrieve the newly created furniture item from the database
        saved_furniture = Furniture.query.filter_by(name='Desk').first()

        # Delete the furniture item
        db.session.delete(saved_furniture)
        db.session.commit()

        # Attempt to retrieve the deleted furniture item from the database
        deleted_furniture = Furniture.query.filter_by(name='Desk').first()

        # Assert that the retrieved deleted furniture item is None
        self.assertIsNone(deleted_furniture)

if __name__ == '__main__':
    unittest.main()
