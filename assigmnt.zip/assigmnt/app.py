from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Database configuration for SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///furniture.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Furniture Model
class Furniture(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    quantity = db.Column(db.Integer, nullable=False)
    location = db.Column(db.String(100), nullable=False)

# Create database tables
with app.app_context():
    db.create_all()


# Route for displaying the form to add a new furniture item
@app.route('/furniture/add', methods=['GET'])
def add_furniture_form():
    return render_template('add_furniture.html')

# Route for creating a new furniture item
@app.route('/furniture', methods=['POST'])
def create_furniture():
    data = request.form
    new_furniture = Furniture(name=data['name'], description=data['description'], quantity=data['quantity'], location=data['location'])
    db.session.add(new_furniture)
    db.session.commit()
    furniture_items = Furniture.query.all()
    return render_template('display_furniture.html', furniture_items=furniture_items)
    

# Route for displaying all furniture items
@app.route('/furniture', methods=['GET'])
def get_all_furniture():
    furniture_items = Furniture.query.all()
    return render_template('display_furniture.html', furniture_items=furniture_items)

# Route for displaying the form to update a furniture item
@app.route('/furniture/<int:id>/update', methods=['GET'])
def update_furniture_form(id):
    furniture_item = Furniture.query.get_or_404(id)
    return render_template('update_furniture.html', furniture=furniture_item)

# Route for updating a furniture item
@app.route('/furniture/<int:id>/update', methods=['POST'])
def update_furniture(id):
    furniture_item = Furniture.query.get_or_404(id)
    data = request.form
    furniture_item.name = data['name']
    furniture_item.description = data['description']
    furniture_item.quantity = data['quantity']
    furniture_item.location = data['location']
    db.session.commit()
    return jsonify({'message': 'Furniture item updated successfully'}), 200

# Route for deleting a furniture item
@app.route('/furniture/<int:id>/delete', methods=['DELETE'])
def delete_furniture(id):
    furniture_item = Furniture.query.get_or_404(id)
    db.session.delete(furniture_item)
    db.session.commit()
    return jsonify({'message': 'Furniture item deleted successfully'}), 200

if __name__ == '__main__':
    app.run(debug=True)



